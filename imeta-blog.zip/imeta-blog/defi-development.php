<?php
include_once("template-parts/footer.php");
include_once("template-parts/header_links.php");
include_once("template-parts/navbar.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
  <meta charset="utf-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">

   <title>Defi development Company | 15+ Successful Projects</title>
   <meta name="description" content="Unlock the world of DeFi with a trusted DeFi development company. We've completed 15+ successful projects. Join us to transform your DeFi vision into reality.">

   <link  href="https://imetatech.io/defi-development" rel="canonical">
     
  <?php echo header_links(); ?>

</head>
<body>


 <style>
  .owl-nav.disabled{
    display: none !important;
  }
</style>   

   <!---------NAVBAR START------>
<?php echo navbar_(); ?>
   <!-----NAVBAR END---->



<section class="Banner3">
   
   <div class="row">
      <div class="col-md-6 left">
         <!-- <h2>Coinbase Clone Script</h2> -->
         <h1><span>DeFi </span> Development</h1>

         <p>From token creation to smart contracts and yield farming, we have your back. iMeta Technologies is here to guide you toward a seamless, profitable DeFi development.</p>    

         <button class="get-btn">Get in touch</button>
      </div>
      <div class="col-md-6 right">
         <img src="assets/images/binance.png">
      </div>
   </div>

</section>



<!-- <section class="What">
   <div class="row">
      <div class="col-md-4">
         <h2>What is the Coinbase Clone Script?</h2>
      </div>
      <div class="col-md-8">
         <p>The Coinbase clone script is pre-constructed software that enables the launch of a replica of the features and functionalities of Coinbase, a well-known bitcoin trading service. Our iMeta Coinbase clone script is designed to provide you with a fully operational platform for establishing your cryptocurrency exchange business. It offers users a secure and user-friendly trading environment while saving you time compared to building a new exchange platform from scratch.</p>
      </div>
   </div>
</section> -->




<!-- <section class="How">

   <div class="row">
      <div class="col-md-12 text-center">
        <h2>How Coinbase Clone Script Works?</h2> 
      </div>
   </div>

   <p class="main_p">Our iMeta Coinbase clone script typically works by replicating the core functionalities and features of the original Coinbase cryptocurrency exchange platform. Here's a simplified overview of how it works:</p>
   
    <div class="row">
       <div class="col-md-6">
          <div class="item">
             <div class="row">
                <div class="col-md-2">
                   <img src="assets/images/icons/user-registration.png">
                </div>
                <div class="col-md-10">
                   <p>Users can sign up for an account on the platform by providing their details and completing a verification process</p>
                </div>
             </div>
          </div>
       </div>
       <div class="col-md-6">
          <div class="item">
             <div class="row">
                <div class="col-md-2">
                   <img src="assets/images/icons/wallet-creation.png">
                </div>
                <div class="col-md-10">
                   <p>After registration, users can create cryptocurrency wallets to store their digital assets securely.</p>
                </div>
             </div>
          </div>
       </div>
       <div class="col-md-6">
          <div class="item">
             <div class="row">
                <div class="col-md-2">
                   <img src="assets/images/icons/deposit.png">
                </div>
                <div class="col-md-10">
                   <p>Users can deposit various cryptocurrencies into their wallets by transferring funds from external sources. They can also withdraw their funds to external wallets or bank accounts.</p>
                </div>
             </div>
          </div>
       </div>
       <div class="col-md-6">
          <div class="item">
             <div class="row">
                <div class="col-md-2">
                   <img src="assets/images/icons/order.png">
                </div>
                <div class="col-md-10">
                   <p>Users can place buy or sell orders for different cryptocurrencies. The platform matches buy and sell orders to facilitate trading.</p>
                </div>
             </div>
          </div>
       </div>
       <div class="col-md-6">
          <div class="item">
             <div class="row">
                <div class="col-md-2">
                   <img src="assets/images/icons/trading.png">
                </div>
                <div class="col-md-10">
                   <p>The platform offers a user-friendly trading interface where users can monitor price charts, execute trades, set limit orders, and access trading pairs.</p>
                </div>
             </div>
          </div>
       </div>
       <div class="col-md-6">
          <div class="item">
             <div class="row">
                <div class="col-md-2">
                   <img src="assets/images/icons/security.png">
                </div>
                <div class="col-md-10">
                   <p>Security is a critical aspect of a cryptocurrency exchange. The Coinbase clone script should include security measures such as encryption, two-factor authentication (2FA), cold storage for funds, and regular security audits.</p>
                </div>
             </div>
          </div>
       </div>
       <div class="col-md-6">
          <div class="item">
             <div class="row">
                <div class="col-md-2">
                   <img src="assets/images/icons/admin.png">
                </div>
                <div class="col-md-10">
                   <p>Administrators have access to a dashboard to manage user accounts, monitor transactions, and implement necessary security measures.</p>
                </div>
             </div>
          </div>
       </div>
       <div class="col-md-6">
          <div class="item">
             <div class="row">
                <div class="col-md-2">
                   <img src="assets/images/icons/liquidity.png">
                </div>
                <div class="col-md-10">
                   <p>To ensure a smooth trading experience, the platform may need to manage liquidity by connecting to various liquidity providers and order books.</p>
                </div>
             </div>
          </div>
       </div>
       <div class="col-md-6">
          <div class="item">
             <div class="row">
                <div class="col-md-2">
                   <img src="assets/images/icons/compliance.png">
                </div>
                <div class="col-md-10">
                   <p>The clone script should incorporate compliance features to adhere to local and international regulations, including KYC and AML procedures.</p>
                </div>
             </div>
          </div>
       </div>
       <div class="col-md-6">
          <div class="item">
             <div class="row">
                <div class="col-md-2">
                   <img src="assets/images/icons/customer.png">
                </div>
                <div class="col-md-10">
                   <p>A support system can be integrated to assist users with inquiries, account issues, or technical problems.</p>
                </div>
             </div>
          </div>
       </div>
       <div class="col-md-6">
          <div class="item">
             <div class="row">
                <div class="col-md-2">
                   <img src="assets/images/icons/revenue.png">
                </div>
                <div class="col-md-10">
                   <p>Revenue can be generated through trading fees, withdrawal fees, and other monetization strategies implemented by the platform operator.</p>
                </div>
             </div>
          </div>
       </div>
    </div>

</section> -->



<section class="Features">
   
   <div class="row">
      <div class="col-md-6">
         <h2>Our Defi Development Services</h2>
         
         <div class="item">
            <h3>DeFi Token Development</h3>
            <p>Creating DeFi tokens tailored to specific project needs. Tokens can represent assets, govern protocols, or be used for liquidity provision.</p>
         </div>  

         <div class="item">
            <h3>DeFi Staking Platform Development</h3>
            <p>Building platforms that enable users to stake their tokens and earn rewards, contributing to network security and liquidity.</p>
         </div> 

         <div class="item">
            <h3>DeFi Exchange Development</h3>
            <p>Creating decentralized exchanges that enable users to trade a wide range of assets without the need for intermediaries.</p>
         </div> 
   

      </div>
      <div class="col-md-6">
         
         <div class="item">
            <h3>Smart Contract Development</h3>
            <p>Developing secure, efficient, and reliable smart contracts to execute various functions autonomously within the DeFi ecosystem.</p>
         </div>

         <div class="item">
            <h3>DeFi Yield Farming Development</h3>
            <p>Designing and implementing yield farming strategies that allow users to earn passive income by providing liquidity or participating in various DeFi protocols.</p>
         </div>

         <div class="item">
            <h3>DeFi dApp Development</h3>
            <p>Developing decentralized applications that leverage DeFi protocols to provide financial services in a user-friendly manner.</p>
         </div>


      </div>
   </div>

</section>




<!-- <section class="Demo">
   <div class="row">
      <div class="col-md-6 left">
         <h2>Coinbase Clone Script Demo & Pricing</h2>
         <p>Are you willing to see the Coinbase Clone Script in action? iMeta is your Coinbase clone script provider, dedicated to ensuring you receive the best solution. Request a demo today to learn more about the platform's capabilities.</p>
         <p>The cost of developing Coinbase clone software varies depending on your unique business requirements and the trading features you plan to implement in the platform. Our pricing options are flexible, enabling you to select a package that aligns with your business objectives.</p>
         
         <a href="#Start"><button class="contact-btn">Contact Us</button></a>
         <button class="learn-btn"><img src="assets/images/icons/telegram.svg">Connect on Telegram</button>

      </div>
      <div class="col-md-6 right">
         <img src="assets/images/demo-img.png">
      </div>
   </div>
</section> -->




<section class="Model">
   <div class="row">
      <div class="col-md-6 left">
          <h2>Coinbase Clone Script Business Models</h2>
           
          <div class="item">
            <img src="assets/images/icons/circle.png">
             <h3>Smart Contract Development</h3>
             <p>Our experts are proficient in creating, auditing, and maintaining smart contracts, ensuring their security and reliability.</p>
          </div> 

          <div class="item">
            <img src="assets/images/icons/circle.png">
             <h3>Decentralized Identity</h3>
             <p>Our technology stack includes decentralized identity solutions to protect user data and ensure compliance.</p>
          </div>

          <div class="item">
            <img src="assets/images/icons/circle.png">
             <h3>Web3 Development</h3>
             <p>Our Web3 development expertise ensures a seamless and user-friendly experience for your DeFi applications, connecting users directly to the blockchain.</p>
          </div>


      </div>
      <div class="col-md-6 right">

         <div class="item">
            <img src="assets/images/icons/circle.png">
             <h3>Blockchain Integration</h3>
             <p>We specialize in integrating various blockchain networks into your DeFi project, whether it's Ethereum, Binance Smart Chain, or others.</p>
          </div>

          <div class="item">
            <img src="assets/images/icons/circle.png">
             <h3>Oracles</h3>
             <p>DeFi platforms depend on accurate external data. We implement robust oracle solutions to feed real-world data into your DeFi applications.</p>
          </div>

          <div class="item">
            <img src="assets/images/icons/circle.png">
             <h3>Cross-Chain Solutions</h3>
             <p>We understand the importance of interoperability. Our tech stack includes cross-chain solutions to make your DeFi project more versatile.</p>
          </div>
         

      </div>
   </div>
</section>




<section class="Demo">
   <div class="row">
      <div class="col-md-12 left">
         <h2>Exchange Clone solutions we offer</h2>
          
          <div class="row">
             <div class="col-md-2 col-6">
                <div class="item text-center">
                  <a href="binance-clone-script.php">
                  <img src="assets/images/icons/binance.svg">
                   <p>Binance Clone Script</p>
                   </a>
                </div>
             </div>
             <div class="col-md-2 col-6">
                <div class="item text-center">
                  <a href="xt-clone-script.php">
                  <img src="assets/images/icons/xt.svg">
                   <p>XT.com Clone Script</p>
                   </a>
                </div>
             </div>
             <div class="col-md-2 col-6">
                <div class="item text-center">
                  <a href="">
                   <img src="assets/images/icons/simplefx.png">
                   <p>SimpleFX Clone</p>
                   </a>
                </div>
             </div>
             <div class="col-md-2 col-6">
                <div class="item text-center">
                  <a href="">
                  <img src="assets/images/icons/localbitcoins.png">
                   <p>LocalBitcoins Clone Script</p>
                   </a>
                </div>
             </div>
             <div class="col-md-2 col-6">
                <div class="item text-center">
                  <a href="">
                  <img src="assets/images/icons/paxful.png">
                   <p>Paxful Clone Script</p>
                   </a>
                </div>
             </div>
             <div class="col-md-2 col-6">
                <div class="item text-center">
                  <a href="remitano-clone-script.php">
                  <img src="assets/images/icons/remitano.png">
                   <p>Remitano Clone Script</p>
                   </a>
                </div>
             </div>
             <div class="col-md-2 col-6">
                <div class="item text-center">
                  <a href="coinbase-clone-script.php">
                  <img src="assets/images/icons/coinbase.svg">
                   <p>Coinbase Clone Script</p>
                   </a>
                </div>
             </div>
             <div class="col-md-2 col-6">
                <div class="item text-center">
                  <a href="">
                  <img src="assets/images/icons/coinswitch.png">
                   <p>Coinswitch Clone Script</p>
                   </a>
                </div>
             </div>
             <div class="col-md-2 col-6">
                <div class="item text-center">
                  <a href="">
                  <img src="assets/images/icons/cryptocom.jpg">
                   <p>Crypto.com Clone Script</p>
                   </a>
                </div>
             </div>
             <div class="col-md-2 col-6">
                <div class="item text-center">
                  <a href="">
                  <img src="assets/images/icons/wazirx.png">
                   <p>Wazirx Clone Script</p>
                   </a>
                </div>
             </div>
             <div class="col-md-2 col-6">
                <div class="item text-center">
                  <a href="">
                  <img src="assets/images/icons/coindcx.svg">
                   <p>CoinDCX Clone Script</p>
                   </a>
                </div>
             </div>
          </div>

      </div>
   </div>
</section>



<section class="Features">
   
   <div class="row">
      <div class="col-md-6">
         <h2>DeFi Use-Cases</h2>
         
         <div class="item">
            <h3>Lending and Borrowing</h3>
         </div> 

         <div class="item">
            <h3>Stablecoins</h3>
         </div>

           <div class="item">
            <h3>Decentralized Identity</h3>
         </div>

         <div class="item">
            <h3>Decentralized Insurance</h3>
         </div>

         <div class="item">
            <h3>Governance and Voting</h3>
         </div>

         <div class="item">
            <h3>Liquidity Provision</h3>
         </div>

         <div class="item">
            <h3>Risk Hedging</h3>
         </div>

      </div>
      <div class="col-md-6">
         
         <div class="item">
            <h3>Decentralized Exchanges</h3>
         </div>

         <div class="item">
            <h3>Automated Market Makers (AMMs)</h3>
         </div>

         <div class="item">
            <h3>Cross-Border Payments</h3>
         </div>

         <div class="item">
            <h3>Tokenization of Assets</h3>
         </div>

         <div class="item">
            <h3>Microloans and Micropayments</h3>
         </div>

         <div class="item">
            <h3>Financial Inclusion</h3>
         </div>

         <div class="item">
            <h3>Token Swaps</h3>
         </div>


      </div>
   </div>

</section>



<section class="Technology" id="Technology">
   
   <h2>Technology Used In Coinbase Clone Script</h2>

   <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="pills-webs-tab" data-toggle="pill" href="#pills-webs" role="tab" aria-controls="pills-webs" aria-selected="true">Programming languages</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="pills-blockchain-tab" data-toggle="pill" href="#pills-blockchain" role="tab" aria-controls="pills-blockchain" aria-selected="false">Frameworks</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="pills-cloud-tab" data-toggle="pill" href="#pills-cloud" role="tab" aria-controls="pills-cloud" aria-selected="false">Database</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="pills-database-tab" data-toggle="pill" href="#pills-database" role="tab" aria-controls="pills-database" aria-selected="false">Blockchain</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="pills-mobileapps-tab" data-toggle="pill" href="#pills-mobileapps" role="tab" aria-controls="pills-mobileapps" aria-selected="false">Smart contracts</a>
  </li>
</ul>

<hr/>

<div class="tab-content" id="pills-tabContent">
  <div class="tab-pane fade show active" id="pills-webs" role="tabpanel" aria-labelledby="pills-webs-tab">
     
     <div class="row">
        <div class="col-md-12 left">
            
            <div class="row">
               <div class="col-md-2 col-6 text-center">
                   <div class="tech-inner">
                   <img src="assets/images/tech/nodejs.svg" class="tech">
                  </div>
               </div>
               <div class="col-md-2 col-6 text-center">
                   <div class="tech-inner">
                   <img src="assets/images/tech/python.svg" class="tech">
                  </div>
               </div>
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                    <img src="assets/images/tech/ruby-on-rails.svg" class="tech">
                  </div>
               </div>
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                   <img src="assets/images/tech/html.svg" class="tech">
                  </div>
               </div>
               <div class="col-md-2 col-6 text-center">
                 <div class="tech-inner">
                   <img src="assets/images/tech/css.svg" class="tech">
                  </div>
               </div>
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                   <img src="assets/images/tech/javascript.svg" class="tech">
                  </div>
               </div>
            </div>

        </div>
     </div>

  </div>
  <div class="tab-pane fade" id="pills-blockchain" role="tabpanel" aria-labelledby="pills-blockchain-tab">
     
     <div class="row">
        <div class="col-md-12 left">

            <div class="row">
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                   <img src="assets/images/tech/express-js.svg" class="tech">
                  </div>
               </div>
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                   <img src="assets/images/tech/django.svg" class="tech">
                  </div>
               </div>
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                   <img src="assets/images/tech/ruby-on-rails.svg" class="tech">
                  </div>
               </div>
            </div>

        </div>
     </div>


  </div>
  <div class="tab-pane fade" id="pills-cloud" role="tabpanel" aria-labelledby="pills-cloud-tab">
     
     <div class="row">
        <div class="col-md-12 left">

            <div class="row">
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                   <img src="assets/images/tech/mysql.svg" class="tech">
                  </div>
               </div>
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                   <img src="assets/images/tech/postgresql.svg" class="tech">
                  </div>
               </div>
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                   <img src="assets/images/tech/mongodb.svg" class="tech">
                  </div>
               </div>
            </div>

        </div>
     </div>

  </div>
  <div class="tab-pane fade" id="pills-database" role="tabpanel" aria-labelledby="pills-database-tab">
     
     <div class="row">
        <div class="col-md-12 left">

            <div class="row">
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                   <img src="assets/images/tech/ethereum.svg" class="tech">
                  </div>
               </div>
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                   <img src="assets/images/tech/binance.svg" class="tech">
                  </div>
               </div>
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                   <img src="assets/images/tech/solana.svg" class="tech">
                  </div>
               </div>
            </div>

        </div>
     </div>

  </div>

  <div class="tab-pane fade" id="pills-mobileapps" role="tabpanel" aria-labelledby="pills-mobileapps-tab">
     
     <div class="row">
        <div class="col-md-12 left">

            <div class="row">
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                   <img src="assets/images/tech/solidity.svg" class="tech">
                  </div>
               </div>
               <div class="col-md-2 col-6 text-center">
                  <div class="tech-inner">
                   <img src="assets/images/tech/rust.png" class="tech">
                  </div>
               </div>
            </div>

        </div>
     </div>

  </div>


</div>

</section>




<!-- <section class="Whitelabel">
   <div class="row">
      <div class="col-md-7 left">
         
         <h2>White Label Solutions for Coinbase Clone Script</h2>
         <p>We are leading experts in developing sophisticated, white-label solutions, with a special focus on the creation of high-quality Coinbase clone scripts. Our firm commitment to excellence in the area of cryptocurrency exchange platforms enables us to deliver an outstanding white-label solution that replicates Coinbase's core functionalities and robust features, all while allowing you to tailor and brand it in accordance with your distinct corporate identity.</p>

         <p>Whether you want to enter the cryptocurrency market for the first time or expand your existing portfolio, our Coinbase clone script provides a flawlessly engineered, cost-effective, and fully customizable path to establishing your very own, unique cryptocurrency exchange platform, putting you at the forefront of the crypto industry.</p>

         <a href="#Start"><button class="contact-btn">Contact Us</button></a>
         <button class="learn-btn"><img src="assets/images/icons/telegram.svg">Connect on Telegram</button>

      </div>
      <div class="col-md-5 right">
         
         <img src="assets/images/whitelabel.jpg">

      </div>
   </div>
</section> -->








<section class="FAQ">
   <h2>Frequently Asked Questions</h2>

   <div id="accordion">
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          What is the first step in DeFi development, and how do we initiate the project?
        </button>
      </h5>
    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
      <div class="card-body">
        The first step is to define your DeFi project's goals and use cases. You should create a detailed project scope, including the DeFi services you want to offer, such as lending, borrowing, trading, or yield farming. iMeta technologies can assist you in formulating a comprehensive project plan and architecture.
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          How can we ensure the security of our DeFi platform, given the increasing number of hacks and vulnerabilities in the DeFi space?
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body">
       Security is a top priority. Our company follows best practices in smart contract development, including code audits, formal verification, and robust testing. We use battle-tested security libraries and follow decentralized finance security standards to minimize the risk of vulnerabilities.
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          What blockchain technology is best suited for our diverse DeFi use cases?
        </button>
      </h5>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
      <div class="card-body">
       The choice of blockchain depends on your project's requirements. Ethereum is a popular choice, but other blockchains like Binance Smart Chain, Polkadot, and Solana may also be suitable. We'll work with you to select the blockchain that aligns with your use cases and scalability needs.
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingFour">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
          How can we attract liquidity providers and users to our DeFi platform?
        </button>
      </h5>
    </div>
    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
      <div class="card-body">
        User adoption and liquidity are key to success. We'll assist in designing incentive programs, yield farming strategies, and liquidity mining campaigns to attract and retain users and liquidity providers. Collaborations with other DeFi projects can also help bootstrap liquidity.
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingFive">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
          What regulatory and compliance considerations should we be aware of when developing a DeFi platform?
        </button>
      </h5>
    </div>
    <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordion">
      <div class="card-body">
        The regulatory landscape is evolving. We advise on incorporating KYC/AML measures, adhering to local and global regulations, and actively monitoring regulatory changes. Legal counsel can help navigate complex regulatory requirements to ensure compliance.
      </div>
    </div>
  </div>

</div>

</section>




<section id="Start">
   
   <div class="row">
      <div class="col-md-12 text-center">
         <h2>START BUILDING<br>
YOUR BLOCKCHAIN VENTURE</h2>
      </div>
   </div>

   
   <div class="row">
      <div class="col-md-6">
         <input type="text" class="input" name="" placeholder="First Name">
      </div>
      <div class="col-md-6">
         <input type="text" class="input" name="" placeholder="Last Name">
      </div>

      <div class="col-md-6">
         <input type="number" class="input" name="" placeholder="Phone Number">
      </div>
      <div class="col-md-6">
         <input type="email" class="input" name="" placeholder="Email Address">
      </div>

      <div class="col-md-6">
         <select>
            <option>Select Industry</option>
            <option>Banking</option>
            <option>Supply Chain</option>
            <option>Automotive</option>
            <option>Energy</option>
            <option>Healthcare</option>
            <option>Pharma</option>
            <option>Real Estate</option>
            <option>Transportation</option>
         </select>
      </div>
      <div class="col-md-6">
         <select>
            <option>Select Expected Budget</option>
            <option>10k-20k</option>
            <option>20k-30k</option>
            <option>30k-40k</option>
            <option>40k-50k</option>
         </select>
      </div>

      <div class="col-md-12">
         <textarea placeholder="Type a message..." rows="6"></textarea>
      </div>
   </div>

   <input type="radio" id="html" name="fav_language" value="agree">
   <label for="html">I agree that my personal information will be processed and stored by IMeta</label><br>

   <button class="send-btn">Send Message</button>



</section>






   <!---------FOOTER START------>
<?php echo footer_(); ?>
   <!---------FOOTER END------>

<!--------------------------- SCRIPTS ------------------------------------->

<!-- <script src="assets/js/bootstrap.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.5.3/js/bootstrap.min.js" integrity="sha512-8qmis31OQi6hIRgvkht0s6mCOittjMa9GMqtK9hes5iEQBQE/Ca6yGE5FsW36vyipGoWQswBj/QBm2JR086Rkw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!-- <script src="assets/js/owl.carousel.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script src="assets/js/sweetalert2.min.js"></script>



</body>
</html>